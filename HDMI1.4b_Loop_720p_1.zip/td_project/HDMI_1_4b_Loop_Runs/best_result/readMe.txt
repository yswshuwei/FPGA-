The implemented result of phy_1 is saved as best result.
