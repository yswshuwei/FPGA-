SWNS: 0.681ns, STNS: 0.000ns.
HWNS: -0.031ns, HTNS: -0.031ns.
